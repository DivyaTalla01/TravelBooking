//
//  ResultViewController.swift
//  talla_TravelBooking
//
//  Created by Divya on 4/2/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var resultOL: UILabel!
    
    @IBOutlet weak var travellerNameOL: UILabel!
    
    @IBOutlet weak var noOfTravellersOL: UILabel!
    
    @IBOutlet weak var cabinTypeOL: UILabel!
    
    @IBOutlet weak var totalCostOL: UILabel!
    
    var name = ""
    var travellers = 0
    var travelClass = ""
    var cost = 0.0
    var image = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //write code for the condition of class not mentioned properly
        if (travelClass == "economy" || travelClass == "luxury") {
            resultOL.text = "Hello \(name), your Booking is Confirmed,"
            imageOL.image = UIImage(named:image)
            travellerNameOL.isHidden = false
            noOfTravellersOL.isHidden = false
            cabinTypeOL.isHidden = false
            totalCostOL.isHidden = false
            travellerNameOL.text = "Name: \(name)"
            noOfTravellersOL.text = "Number of Travellers: \(travellers)"
            cabinTypeOL.text = "Cabin Class: \(travelClass)"
            totalCostOL.text = "Total: \(cost)$"
        } else {
            resultOL.text = "There is no selected class. Please choose a valid class."
            imageOL.image = UIImage(named:image)
            travellerNameOL.isHidden = true
            noOfTravellersOL.isHidden = true
            cabinTypeOL.isHidden = true
            totalCostOL.isHidden = true
        }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
