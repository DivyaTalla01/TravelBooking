//
//  ViewController.swift
//  Talla_TravelBooking
//
//  Created by Divya on 4/2/24.
//

import UIKit

class BookingViewController: UIViewController {
    
    @IBOutlet weak var travellerNameOL: UITextField!
    
    @IBOutlet weak var noOfTravellersOL: UITextField!
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    var name = ""
    var travellers = 0
    var travelClass = ""
    var cost = 0.0
    var image = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func bookNowButton(_ sender: Any) {
        // feed the cabin class data and other data to the variables
        name = travellerNameOL.text!
        travelClass = (cabinTypeOL.text!).lowercased()
        if let text = noOfTravellersOL.text, let travellersCount = Int(text) {
            travellers = travellersCount
        } else {
            travellers = 0
        }
        //check the class and find the cost accordingly
        if travelClass == "economy"{
            cost = Double(travellers)*125
            image = "economy"
        } else if travelClass == "luxury"{
            cost = Double(travellers)*200
            image = "luxury"
        } else {
            image = "noSelect"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //know the identifier
        let transition = segue.identifier
        //set the destination
        if(transition == "resultSegue"){
            let destination = segue.destination
            as! ResultViewController
            //assign values to the destination variables
            destination.name = name
            destination.travellers = travellers
            destination.travelClass = travelClass
            destination.cost = cost
            destination.image = image
        }
    }
}

